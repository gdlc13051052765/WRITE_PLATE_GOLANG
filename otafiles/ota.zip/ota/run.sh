#kill -9 $(pidof  golang)
kill -9 $(pidof  WriteDisk)

chmod 777 * /home/meican/ota
cp -r  /home/meican/ota/WriteDisk /home/meican
#cp -r  /home/meican/ota/golang /home/meican
#chmod 777 /home/meican/golang
chmod 777 /home/meican/WriteDisk

#/home/meican/golang
/home/meican/WriteDisk

